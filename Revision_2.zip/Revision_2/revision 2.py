''' Andrew Kennedy 2023
    This program is in support for my 13PRG Assessment'''

# Import Tkinter & pygame for GUI & music implementation
from tkinter import *
from PIL import Image, ImageTk
from pygame import mixer
from tkinter import filedialog

# Initialise Root 
root = Tk()                                                                     # Create root window
root.title("Music Player")                                                      # name root window
root.configure(bg="#282828")

mixer.init(size=-16, channels=2, buffer=16384)



class Player:                                                                   # Initialization of the Player class

    def update_song(self):
        mixer.music.load(self.track_list[self.track_position])  

    def get_cover_art(self):
        pass

    def select_file(self):
        try:
            #Open file explorer
            self.selected_file = filedialog.askopenfilename(
                initialdir = "/",
                title = "Select file",
                filetypes = (("MP3 files", "*.mp3"),("All files", "*.*"))
                )
            # Show selected file in label
            self.entry_song.config(
                text="Selected file: \n" + self.selected_file, 
                font=("Arial", "8"), 
                width= 35)
        except:
            print(f"yout a position {self.track_position} with a track list of {len(self.track_list)}")

            print("unable to comeplete request")

    def program_quit(self):                                                     # Exit Function for GUI
        root.destroy()

    def add_song(self):
        try:
            if self.selected_file != '':
            
                if self.track_list != None:
                    self.track_list.append(self.selected_file)
                    self.update_song()
                else:
                    self.track_list.append(self.selected_file)

            else: raise ValueError

        except:
            print(f"yout a position {self.track_position} with a track list of {(self.track_list)}")

            print("unable to comeplete request")


    def play_pause_trigger(self):
        try:

            if self.active_player == False:
                self.update_song()
                mixer.music.play()
                self.active_player = True
                
            elif self.active_player == True:
                mixer.music.pause()
                self.active_player = False
        except:
            print(f"yout a position {self.track_position} with a track list of {len(self.track_list)}")

            print("unable to comeplete request")

    def prior_song_trigger(self):
        try:
            if self.track_position <= 0: raise IndexError

            else: 
                if self.active_player == False:
                    self.active_player = True
                    
                self.track_position = self.track_position - 1
                self.update_song()
                mixer.music.play()

        except:
            print(f"yout a position {self.track_position} with a track list of {len(self.track_list)}")
            print("unable to comeplete request")

    def skip_song_trigger(self):
        try:
            if self.track_position == (len(self.track_list) - 1): raise IndexError

            else: 
                if self.active_player == False:
                    self.active_player = True
                    
                self.track_position = self.track_position + 1
                self.update_song()
                mixer.music.play()

            print(self.track_position)
        except:
            print(f"yout a position {self.track_position} with a track list of {len(self.track_list)}")
            print("unable to comeplete request")


        

    def __init__(self):

        '''Below contains data on behalf of the GUI, this is the interface/front end
		the user with interface with'''

        self.selected_file = ""
        self.track_list = []
        self.track_position = 0

        self.active_player = False
        self.background_colour = "#282828"                                      # Set background color to "main"
        
        self.player_frame_banner = Frame(bg=self.background_colour)                                     
        self.player_frame_banner.grid(row=0, padx=15, pady=5)

        self.player_frame_menu = Frame(bg=self.background_colour)                                       
        self.player_frame_menu.grid(row=1)

        self.player_frame_input = Frame(bg=self.background_colour)                                         
        self.player_frame_input.grid(row=2)

        self.current_song_label_image = ImageTk.PhotoImage(                     # Initializing Image for current_song_label Button
            file=f"cover_art/Demo_Track_label.png")

        self.current_song_label = Button(
            self.player_frame_banner,
            width=250,
            height=250, 
            image=self.current_song_label_image, 
            border="0", 
            bg=self.background_colour, 
            activebackground=self.background_colour, 
            command=lambda: self.play_pause_trigger(self.active_player)
        )
        
        self.current_song_label.grid(row=0, column=0, columnspan=3, rowspan=4, 
                                     padx=5, pady=5
        )
        
        self.prior_button = PhotoImage(file="prior_button.png")
        self.button_prior = Button(
            self.player_frame_menu,
            image=self.prior_button, 
            border="0", 
            bg=self.background_colour, 
            activebackground=self.background_colour, 
            command=self.prior_song_trigger
        )

        self.button_prior.grid(row=0, column=0, padx=5, pady=5)
        

        self.play_button = PhotoImage(file="play_button.png")
        self.button_play = Button(
            self.player_frame_menu,
            image=self.play_button, 
            border="0", 
            bg=self.background_colour, 
            activebackground=self.background_colour, 
            command=self.play_pause_trigger
        )

        self.button_play.grid(row=0, column=1, padx=5, pady=5)      


        self.skip_button = PhotoImage(file="skip_button.png")
        self.button_next = Button(
            self.player_frame_menu,
            image=self.skip_button, 
            border="0", 
            bg=self.background_colour, 
            activebackground=self.background_colour, 
            command=self.skip_song_trigger
        )

        self.button_next.grid(row=0, column=2, padx=5, pady=5)

        self.song_entry = PhotoImage(file="song_entry.png")
        self.entry_song = Button(
            self.player_frame_input,
            border="0", 
            activebackground=self.background_colour, 
            bg="#D9D9D9", 
            fg="#282828",
            text="Select song",
            width=25,
            font=('Arial', 12, 'bold'),
            command=self.select_file
            )
        self.entry_song.grid(row=0, column=0, padx=5, pady=0, columnspan=2)


        self.add_button = PhotoImage(file="add_button.png")
        self.button_add = Button(
            self.player_frame_input,
            image=self.add_button, 
            border="0", 
            bg=self.background_colour, 
            activebackground=self.background_colour, 
            command=self.add_song
        )
        self.button_add.grid(row=0, column=2, padx=5, pady=0)

        


player = Player()

root.mainloop()
