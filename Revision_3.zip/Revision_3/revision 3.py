''' Andrew Kennedy 2023
    This program is in support for my 13PRG Assessment'''

# Import Tkinter & pygame for GUI & music implementation
from tkinter import *
from PIL import Image, ImageTk
from pygame import mixer
from tkinter import filedialog
from tkinter import ttk
import requests
import os
from PIL import Image, ImageDraw
from PIL import Image, ImageTk
from mutagen.mp3 import MP3
import customtkinter
import time

# Initialise Root 
root = Tk()                                                                     # Create root window
root.title("Music Player")                                                      # name root window
root.configure(bg="#282828")

class Player:                                                                   # Initialization of the Player class      

    def downlaod_cover_art(self, song_name, file_name):
        # Deezer API endpoint for track search
        api = 'https://api.deezer.com/search'

        try:
            os.remove("cover_art/track_cover.png")
        except: 
            pass

        # Parameters for track search
        label_name = {'q': song_name}

        # Send a GET request to Deezer API
        response = requests.get(api, params=label_name)
        
        data = response.json()
        track = data['data'][0]

        track_title = track['title']
        artist_name = track['artist']['name']
        cover_url = track['album']['cover_medium']

        # Create a directory to save the cover art
        directory = 'cover_art'
        if not os.path.exists(directory):
            os.makedirs(directory)

        # Download the cover art
        response = requests.get(cover_url)

        file_path = f'{directory}/{file_name}'

        print(f"{directory}/{track_title} - {artist_name} DOWLOADED!")

        with open(file_path, 'wb') as file:

            file.write(response.content)

        im = Image.open(file_path)#curve
        im = self.add_corners(im, 11)
        im.save(file_path)

    def add_corners(self, im, rad): # CoDE FROM STACK OVERFLOW https://stackoverflow.com/questions/11287402/how-to-round-corner-a-logo-without-white-backgroundtransparent-on-it-using-pi
        circle = Image.new('L', (rad * 2, rad * 2), 0)
        draw = ImageDraw.Draw(circle)
        draw.ellipse((0, 0, rad * 2 - 1, rad * 2 - 1), fill=255)
        alpha = Image.new('L', im.size, 255)
        w, h = im.size
        alpha.paste(circle.crop((0, 0, rad, rad)), (0, 0))
        alpha.paste(circle.crop((0, rad, rad, rad * 2)), (0, h - rad))
        alpha.paste(circle.crop((rad, 0, rad * 2, rad)), (w - rad, 0))
        alpha.paste(circle.crop((rad, rad, rad * 2, rad * 2)), (w - rad, h - rad))
        im.putalpha(alpha)
        return im


    def update_song(self):
        mixer.music.load(self.track_list[self.track_position])  

        song_location = os.path.basename(self.track_list[self.track_position])
        song_name, song_path = os.path.splitext(song_location)
        song_name = song_name.strip()
        
        try:
       
            self.downlaod_cover_art(song_name, "track_cover.png")
            
            self.updated_song_label_image = ImageTk.PhotoImage(
                file=f"cover_art/track_cover.png")

            self.current_song_label.configure(
                image=self.updated_song_label_image)
            self.current_song_label.image = self.updated_song_label_image

        except:

            self.updated_song_label_image = ImageTk.PhotoImage(
                file=f"cover_art/placeholder.png")
            self.current_song_label.configure(
                image=self.updated_song_label_image)
            self.current_song_label.image = self.updated_song_label_image

    def select_file(self):
        try:
            #Open file explorer
            self.selected_file = filedialog.askopenfilename(
                initialdir = "/",
                title = "Select file",
                filetypes = (("MP3 files", "*.mp3"),("All files", "*.*"))
                )
            # Show selected file in label

            song_location = os.path.basename(self.selected_file)
            song_name, song_path = os.path.splitext(song_location)
            song_name = song_name.strip()

            if song_name == '':
                self.entry_song.configure(text="Select song")
            else:
                self.entry_song.configure(text=song_name +".mp3")

            
        except:
            print(f"yout a position {self.track_position} with a track list of {len(self.track_list)}")

            print("unable to comeplete request")

    def program_quit(self):                                                     # Exit Function for GUI
        root.destroy()

    def add_song(self):
        try:
            if self.selected_file != '':
            
                if self.track_list == []:
                    
                    mixer.init(size=-16, channels=2, buffer=16384)
                    self.track_list.append(self.selected_file)
                    self.update_song()

                    self.selected_file = ''
                    self.entry_song.configure(text="Select song")
                    
                else:
                    self.track_list.append(self.selected_file)
                    self.selected_file = ''
                    self.entry_song.configure(text="Select song")

            else: raise ValueError

        except:
            print(f"yout a position {self.track_position} with a track list of {(self.track_list)}")

            print("unable to comeplete request")


    def play_pause_trigger(self):
        try:

            if self.active_player == False:
                self.update_song()

                mixer.music.play()    

                self.active_player = True

                self.pause_button = ImageTk.PhotoImage(file="pause_button.png")
                self.button_play.configure(image=self.pause_button)
                self.button_play.image = self.pause_button

                
            elif self.active_player == True:
                mixer.music.pause()
                self.active_player = False

                self.play_button = ImageTk.PhotoImage(file="play_button.png")
                self.button_play.configure(image=self.play_button)
                self.button_play.image = self.play_button

        except:
            print(f"yout a position {self.track_position} with a track list of {len(self.track_list)}")

            print("unable to comeplete request")

    def prior_song_trigger(self):
        try:
            if self.track_position <= 0: raise IndexError

            else: 
                if self.active_player == False:
                    self.active_player = True
                    
                self.track_position = self.track_position - 1
                self.update_song()

                mixer.music.play()   

                self.pause_button = ImageTk.PhotoImage(file="pause_button.png")
                self.button_play.configure(image=self.pause_button)
                self.button_play.image = self.pause_button

        except:
            print(f"yout a position {self.track_position} with a track list of {len(self.track_list)}")
            print("unable to comeplete request")

    def skip_song_trigger(self):
        try:
            if self.track_position == (len(self.track_list) - 1): raise IndexError

            else: 
                if self.active_player == False:
                    self.active_player = True
                    
                self.track_position = self.track_position + 1
                self.update_song()

                mixer.music.play()   

                self.pause_button = ImageTk.PhotoImage(file="pause_button.png")
                self.button_play.configure(image=self.pause_button)
                self.button_play.image = self.pause_button

            print(self.track_position)
        except:
            print(f"yout a position {self.track_position} with a track list of {len(self.track_list)}")
            print("unable to comeplete request")


    def set_volume(self, volume):
        try:
            mixer.music.set_volume(float(volume) / 100.0)
        except:
            print("no song currently playing")


    def __init__(self):

        '''Below contains data on behalf of the GUI, this is the interface/front end
		the user with interface with'''

        self.selected_file = ""
        self.track_list = []
        self.track_position = 0

        self.active_player = False
        self.background_colour = "#282828"   # Set background color to "main"
        self.common_colour = "#D9D9D9"

        #self.volume_scale.set(50)  # Set initial volume to 50                                   
        
        self.player_frame_banner = Frame(bg=self.background_colour)                                     
        self.player_frame_banner.grid(row=0)

        self.player_frame_volume = Frame(bg=self.background_colour)                                         
        self.player_frame_volume.grid(row=1)

        self.player_frame_menu = Frame(bg=self.background_colour)                                       
        self.player_frame_menu.grid(row=2)

        self.player_frame_progress = Frame(bg=self.background_colour)                                         
        self.player_frame_progress.grid(row=3)

        self.player_frame_input = Frame(bg=self.background_colour)                                         
        self.player_frame_input.grid(row=4, pady=10)

        

        self.current_song_label_image = ImageTk.PhotoImage(                     # Initializing Image for current_song_label Button
            file=f"cover_art/welcome.png")

        self.current_song_label = Label(
            self.player_frame_banner,
            width=250,
            height=250, 
            image=self.current_song_label_image, 
            border="0", 
            bg=self.background_colour, 
            activebackground=self.background_colour, 
        )
        
        self.current_song_label.grid(row=0, column=0, 
        padx=30, pady=15
        )

        self.low_volume_icon_image = PhotoImage(file="volume_low_icon.png")
        self.low_volume_icon = Label(
            self.player_frame_volume,
            image=self.low_volume_icon_image,
            bg=self.background_colour
        )
        self.low_volume_icon.grid(row=0, column=0, padx=2, pady=2)

        self.volume_scale = customtkinter.CTkSlider(
            self.player_frame_volume,
            button_hover_color="#808080",
            from_=0, 
            to=100, 
            button_color=self.common_colour,
            command=self.set_volume
        )

        self.volume_scale.set(100)
        self.volume_scale.grid(row=0, column=1, padx=2, pady=2)

        self.high_volume_icon_image = PhotoImage(file="volume_high_icon.png")
        self.high_volume_icon = Label(
            self.player_frame_volume,
            image=self.high_volume_icon_image,
            bg=self.background_colour
        )
        self.high_volume_icon.grid(row=0, column=2, padx=2, pady=2)

        self.prior_button = PhotoImage(file="prior_button.png")
        self.button_prior = Button(
            self.player_frame_menu,
            image=self.prior_button, 
            border="0", 
            bg=self.background_colour, 
            activebackground=self.background_colour, 
            command=self.prior_song_trigger
        )

        self.button_prior.grid(row=0, column=0, padx=5, pady=5)
        

        self.play_button = PhotoImage(file="play_button.png")
        self.button_play = Button(
            self.player_frame_menu,
            image=self.play_button, 
            border="0", 
            bg=self.background_colour, 
            activebackground=self.background_colour, 
            command=self.play_pause_trigger
        )

        self.button_play.grid(row=0, column=1, padx=5, pady=5)      


        self.skip_button = PhotoImage(file="skip_button.png")
        self.button_next = Button(
            self.player_frame_menu,
            image=self.skip_button, 
            border="0", 
            bg=self.background_colour, 
            activebackground=self.background_colour, 
            command=self.skip_song_trigger
        )

        self.button_next.grid(row=0, column=2, padx=5, pady=5)

        self.entry_song = customtkinter.CTkButton(
            self.player_frame_input,
            #border="0", 
            #activebackground=self.background_colour, 
            fg_color=self.common_colour, 
            text_color=self.background_colour,
            hover_color=self.common_colour,
            text="Select song",
            width=200,
            font=('Arial', 16, 'bold'),
            command=self.select_file
            )
        self.entry_song.grid(row=0, column=0, padx=5, pady=0, columnspan=2)


        self.add_button = PhotoImage(file="add_button.png")
        self.button_add = Button(
            self.player_frame_input,
            image=self.add_button, 
            border="0", 
            height=30,
            width=30,
            bg=self.background_colour, 
            activebackground=self.background_colour, 
            command=self.add_song
        )
        self.button_add.grid(row=0, column=2, padx=5, pady=0)



if __name__ == '__main__':

    player = Player()
    root.mainloop()
    

