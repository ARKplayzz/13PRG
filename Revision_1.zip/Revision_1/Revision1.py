''' Andrew Kennedy 2023
    This program is in support for my 13PRG Assessment'''

# Import Tkinter & pygame for GUI & music implementation
from tkinter import *
from PIL import Image, ImageTk
from pygame import mixer

# Initialise Root 
root = Tk()                                                                     # Create root window
root.title("Music Player")                                                      # name root window
root.configure(bg="#282828")

mixer.init(size=-16, channels=2, buffer=16384)
mixer.music.load("music.mp3")


class Player:                                                                   # Initialization of the Player class

    def program_quit(self):                                                     # Exit Function for GUI
        root.destroy()

    def play_pause_trigger(self):
        if self.active_player == False:
            mixer.music.play()
            self.active_player = True
        elif self.active_player == True:
            mixer.music.pause()
            self.active_player = False

    def prior_song_trigger(self):
        pass  # Add previous song functionality

    def skip_song_trigger(self):
        pass  # Add song functionality

    def __init__(self):
        self.active_player = False
        background_colour = "#282828"                                           # Set background color to "main"
        font_colour = "white"                                                   # Defining the Font-Colour for the music player

        '''Below contains data on behalf of the GUI, this is the interface/front end
		the user with interface with'''

        self.current_song_label_image = ImageTk.PhotoImage(                     # Initializing Image for current_song_label Button
            file=f"cover_art/Demo_Track_label.png")

        self.current_song_label = Button(
            width=250,
            height=250, 
            image=self.current_song_label_image, 
            border="0", 
            bg=background_colour, 
            activebackground=background_colour, 
            command=lambda: self.play_pause_trigger(self.active_player)
        )
        
        self.current_song_label.grid(row=1, column=1, columnspan=3, rowspan=4, 
                                     padx=0, pady=20
        )
        
        self.prior_button = PhotoImage(file="prior_button.png")
        self.button_prior = Button(
            image=self.prior_button, 
            border="0", 
            bg=background_colour, 
            activebackground=background_colour, 
            command=self.prior_song_trigger
        )

        self.button_prior.grid(row=9, column=1, padx=1, pady=10)
        

        self.play_button = PhotoImage(file="play_button.png")
        self.button_play = Button(
            image=self.play_button, 
            border="0", 
            bg=background_colour, 
            activebackground=background_colour, 
            command=self.play_pause_trigger
        )

        self.button_play.grid(row=9, column=2, padx=1, pady=10)      


        self.skip_button = PhotoImage(file="skip_button.png")
        self.button_next = Button(
            image=self.skip_button, 
            border="0", 
            bg=background_colour, 
            activebackground=background_colour, 
            command=self.skip_song_trigger
        )

        self.button_next.grid(row=9, column=3, padx=2, pady=10)


player = Player()

root.mainloop()
